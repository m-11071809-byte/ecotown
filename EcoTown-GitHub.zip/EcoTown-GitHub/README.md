# EcoTown

A pixel-style environmental education / city-management web game.

## Project structure

```text
EcoTown/
├── index.html
├── css/
│   ├── style.css
│   └── pixel.css
├── js/
│   └── game.js
├── assets/
└── README.md
```

## Run locally

Open `index.html` in a browser.

## GitHub Pages

1. Create a GitHub repository.
2. Upload all files and folders while keeping the structure above.
3. Go to **Settings → Pages**.
4. Choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save.

Your game will then be available through GitHub Pages.

## Main systems

- Free building placement
- NPC movement and dialogue
- City needs
- Quests and random events
- Weather / day-night cycle
- Building upgrades
- Technology progression
- Coins and XP / leveling
- Mini-games
- Pixel-style presentation
